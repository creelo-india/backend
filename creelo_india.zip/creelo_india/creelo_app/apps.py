from django.apps import AppConfig


class CreeloAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'creelo_app'
